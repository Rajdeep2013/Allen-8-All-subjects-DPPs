import re,glob,os,json,collections
FOOT=re.compile(r'(smd_data|Found\. JEE|SET-\d|Print Module|\[\d+\]\s*$|^\s*\d+\s*$)',re.I)
HDR=re.compile(r'^\s*(.{0,60}?)\s+DPP\s*[–-]\s*(\d+)\s*$',re.M)
SOLHDR=re.compile(r'^\s*SOLUTIONS?\s+DPP\s*[–-]?\s*(\d+)\s*$',re.M)
def clean(s):
    lines=[l.strip() for l in s.split('\n')]
    out=[]
    for l in lines:
        if not l or FOOT.search(l): continue
        out.append(l)
    return re.sub(r'\s+',' ',' '.join(out)).strip()
def parse_file(path):
    t=open(path,encoding='utf8',errors='ignore').read()
    subj=os.path.basename(path).split('__')[0].replace('DPPs','').replace('DPP','')
    topic=os.path.basename(path).split('__')[1][:-4].replace('_',' ').replace('RACE','').replace('Solutions','').strip(' _-').replace('  ',' ')
    # sheets: question-sheet headers
    items=[]
    marks=[(m.start(),'Q',int(m.group(2))) for m in HDR.finditer(t)]+[(m.start(),'S',int(m.group(1))) for m in SOLHDR.finditer(t)]
    marks.sort()
    for i,(pos,kind,n) in enumerate(marks):
        if kind!='Q': continue
        end=marks[i+1][0] if i+1<len(marks) else len(t)
        qblock=t[pos:end]
        # solutions block: from matching SOLUTIONS header to next Q header
        sol=''
        for j in range(i+1,len(marks)):
            if marks[j][1]=='S' and marks[j][2]==n:
                send=marks[j+1][0] if j+1<len(marks) else len(t)
                sol=t[marks[j][0]:send]; break
        if not sol: continue
        # split questions by number at line start
        qs=re.split(r'\n\s*(?=\d{1,2}\.\s*(?:\n|\S))',qblock)
        # sol answers: find "Option (k)" in order
        sol_opts=re.findall(r'Option\s*\(\s*(\d)\s*\)',sol)
        qparts=[]
        for q in qs:
            m=re.match(r'\s*(\d{1,2})\.\s*(.*)',q,re.S)
            if not m: continue
            qn=int(m.group(1))
            body=m.group(2)
            opts={}
            om=list(re.finditer(r'(?m)^\s*\(([1-4])\)\s*',body))
            if len(om)>=4:
                first=om[0].start()
                stem=clean(body[:first])
                seq=[]
                for k,mm in enumerate(om):
                    e=om[k+1].start() if k+1<len(om) else len(body)
                    seq.append((mm.group(1),clean(body[mm.end():e])))
                opt_list=[]
                for num,txt in seq[:4]:
                    opt_list.append(txt)
                qparts.append({'n':qn,'stem':stem,'options':opt_list})
            else:
                qparts.append({'n':qn,'stem':clean(body),'options':None})
        items.append({'subject':subj,'topic':topic,'dpp':n,'questions':qparts,'answers':sol_opts,'sol_raw':sol})
    return items
if __name__=='__main__':
    allitems=[]
    for f in sorted(glob.glob('*.txt')):
        it=parse_file(f)
        mcq=sum(1 for s in it for q in s['questions'] if q['options'])
        tot=sum(len(s['questions']) for s in it)
        print(f"{f[:55]:55s} dpps={len(it):3d} qs={tot:4d} mcq4={mcq:4d} answers_found={sum(len(s['answers']) for s in it)}")
        allitems+=it
    json.dump(allitems,open('/home/claude/parsed.json','w'),ensure_ascii=False)
