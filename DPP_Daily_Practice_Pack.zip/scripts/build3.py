import re,glob,os,json,collections,sys
sys.path.insert(0,'/home/claude')
from parse import HDR,SOLHDR,clean
FLAG=re.compile(r'(picture|figure|diagram|below|above|table|graph|shown|column|match|fig\.|image|circuit|arrangement|given)',re.I)
NUMLINE=re.compile(r'(?m)^\s*(\d{1,2})\.\s*$|^\s*(\d{1,2})\.\s+(?=\S)')
def strict_questions(qblock):
    """Split by number lines; accept a segment only if: number line -> stem -> (1)..(4) in ONE segment, exactly one number line."""
    marks=[(m.start(), int(m.group(1) or m.group(2)), m.end()) for m in NUMLINE.finditer(qblock)]
    out=[]
    for k,(s,n,e) in enumerate(marks):
        end=marks[k+1][0] if k+1<len(marks) else len(qblock)
        seg=qblock[e:end]
        # reject if the next segment starts with a number-only line (batched numbering)
        om=[m for m in re.finditer(r'(?m)^\s*\(([1-4])\)\s*',seg)]
        if [m.group(1) for m in om][:4]!=['1','2','3','4']: continue
        stem=clean(seg[:om[0].start()])
        if len(stem)<10: continue
        opts=[]
        for q in range(4):
            st=om[q].end(); en=om[q+1].start() if q<3 else len(seg)
            opts.append(clean(seg[st:en]))
        if any(not o for o in opts): continue
        out.append((n,stem,opts,s))
    return out
def process(path):
    t=open(path,encoding='utf8',errors='ignore').read()
    fname=os.path.basename(path)
    subj=fname.split('__')[0].replace('DPPs','').replace('DPP','')
    topic=re.sub(r'\s+',' ',fname.split('__')[1][:-4].replace('_',' ').replace('RACE','').replace('Solutions','').replace('Solution','').replace('Test','').strip(' _-'))
    marks=sorted(set([(m.start(),'Q',int(m.group(2))) for m in HDR.finditer(t)]+[(m.start(),'S',int(m.group(1))) for m in SOLHDR.finditer(t)]))
    out=[]
    for i,(pos,kind,n) in enumerate(marks):
        if kind!='Q': continue
        sidx=next((j for j in range(i+1,len(marks)) if marks[j][1]=='S' and marks[j][2]==n),None)
        if sidx is None: continue
        ss=marks[sidx][0]
        se=next((marks[j][0] for j in range(sidx+1,len(marks)) if marks[j][1]=='Q'),len(t))
        qblock=t[pos:ss]; sol=t[ss:se]
        page=t.count('\f',0,pos)+1
        for qn,stem,opts,_ in strict_questions(qblock):
            m=re.search(rf'(?m)^\s*{qn}\.\s*(?:\n\s*){{0,4}}Option\s*\(([1-4])\)',sol)
            if not m: continue
            ans=int(m.group(1))
            after=sol[m.end():]
            nx=re.search(r'(?m)^\s*\d{1,2}\.\s*(?:\n|$)',after)
            expl=clean(after[:nx.start()] if nx else after[:600])[:500]
            out.append({'subject':subj,'topic':topic,'dpp':n,'qno':qn,'page':page,'stem':stem,'options':opts,'answer':ans,'explanation':expl,'flag':bool(FLAG.search(stem)),'file':fname})
    return out
allq=[]
for f in sorted(glob.glob('*.txt')):
    r=process(f); allq+=r; print(f"{f[:50]:50s} {len(r)}")
print(collections.Counter(q['subject'] for q in allq), len(allq), 'flagged',sum(q['flag'] for q in allq))
json.dump(allq,open('/home/claude/questions.json','w'),ensure_ascii=False,indent=1)
