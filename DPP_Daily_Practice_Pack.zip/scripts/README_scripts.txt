parse.py    : shared regex helpers (DPP header and SOLUTIONS header detection, text cleanup)
build3.py   : strict extractor. Reads all .txt files in the current folder (made with pdftotext),
              keeps only questions whose number, stem, and four options sit in one unambiguous block,
              and attaches the answer from the matching SOLUTIONS block.
Next step (manual): run the consistency filter (stem length, no question marks, keyed option wording
              appears in the explanation) and review the survivors before import.
