# DPP Daily Practice: Plan

## 1. What I received
Your upload is a zip with four nested subject zips (Physics, Chemistry, Maths, Biology). Totals:

| Subject   | PDF files | Pages | DPP solution sheets | Questions verified into the app |
|-----------|----------:|------:|--------------------:|--------------------------------:|
| Physics   | 6         | 184   | 37                  | 8                               |
| Chemistry | 4         | 145   | 42                  | 5                               |
| Maths     | 9         | 261   | 55                  | 3                               |
| Biology   | 5         | 100   | 36                  | 19                              |
| **Total** | **24**    | **690** | **170**           | **35**                          |

Per-file detail is in `inventory.csv`.

The material is Class 8 foundation DPPs (JEE/NEET foundation). Each sheet has a question page and a
separate "SOLUTIONS DPP-NN" page with an answer key and explanations. The question types are mixed:
- 4-option MCQs (the only type the app uses)
- Single-correct and multi-correct MCQs
- True/false, one-word fill-ins, subjective questions
- Matching columns and diagram-based questions (the picture is not in the text layer)
- Physics "Magnetic Effects" is a 20-question test, not a DPP set

## 2. Honest status
The app and the schedule are complete and tested. The question bank is the bottleneck.

Automatic extraction from these PDFs is unreliable. The PDF text layer puts question numbers,
stems, and answer keys out of order, so a number can end up attached to the wrong stem. I checked
this directly: one stem was keyed to another question's answer. Rather than ship wrong answers, I
kept only the 35 items that pass consistency checks (the stem is clean, and the keyed option's wording
appears in its explanation). Please spot-check them.

Roughly 600 four-option MCQs appear in the text layer, so the remaining bank is recoverable. It
needs a verified pass, not a guess.

## 3. Daily practice rule
- 5 questions per subject per day (Physics, Chemistry, Maths, Biology), so 20 questions a day.
- Questions are taken in order: by PDF file (chapter), then DPP sheet, then question number.
- Day N takes questions 5(N-1)+1 through 5N from each subject's queue.
- A subject with fewer questions shows fewer on its days. The app says so.
- Mistakes go to a revision queue, which you can practice at any time.
- Expected time: about 30 to 40 minutes a day for 20 questions with explanations.

## 4. What the app does (`dpp_practice_app.html`)
- Home: today's day, the 20-question set, per-subject buttons, day calendar, and progress per subject.
- Quiz: one question at a time. Choose an option (or press 1 to 4). The answer is locked, and the
  correct option, explanation, and PDF source page are shown.
- Revise mistakes: a queue of questions answered wrong on their last attempt.
- Question bank: import more questions as JSON, remove imported questions, see counts, reset progress.
- Progress and streak are saved in your browser (localStorage). Nothing leaves your device.
- Works on phone and desktop. No internet needed after download.

## 5. Roadmap to a complete bank
1. Verify the 35 included items (about 10 minutes).
2. For each of the 170 DPP sheets, produce the MCQs with a verified answer. Two routes:
   - Page-image transcription: render each sheet's question and solution pages to images, and read
     the question and key directly. Most accurate. This is the route I recommend for the remaining
     work. It takes time, but each sheet is checked against its image.
   - Improved layout-aware extraction (word coordinates), then the same consistency checks as the
     included 35, plus a human pass.
3. Import the verified JSON through Question bank > Import.
4. Check the schedule length (the app shows "Day X of N").

Non-MCQ items (true/false, fill-in, subjective) can be added later as self-check cards.

## 6. Files in this pack
- `dpp_practice_app.html`: the app. Open it in any browser.
- `question_bank.json`: the 35 auto-checked questions the app ships with.
- `question_bank_TEMPLATE.json`: the import format. Each item needs id, subject, topic, dpp, qno,
  source, stem, options (4 strings), answer (1 to 4), explanation.
- `inventory.csv`: every PDF with page count, sheet count, and bank count.
- `extracted_text/`: raw text of each PDF, one file per PDF, for reference or verification.
- `scripts/`: the extraction and consistency-check scripts used to build the bank.
- `README.txt`: quick start.
