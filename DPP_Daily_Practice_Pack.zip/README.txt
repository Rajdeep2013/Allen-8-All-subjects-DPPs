DPP DAILY PRACTICE PACK
=======================

START HERE
1. Open dpp_practice_app.html in Chrome, Edge, Safari, or Firefox (double-click it).
2. Press "Start today's set" for 5 questions per subject (up to 20).
3. Choose an answer. Press 1-4 on the keyboard for speed. Enter goes to Next.
4. Use "Revise mistakes" to repeat questions you got wrong.

IMPORTANT
- The bank currently has 35 auto-checked questions. Please verify them.
- The full bank (about 600 candidate MCQs from the PDFs) still needs verification. See PLAN.md.
- Add verified questions via "Question bank" > Import, using question_bank_TEMPLATE.json as the format.

PROGRESS
- Progress is stored in this browser only. Clearing site data erases it.
- Reset all progress from "Question bank".

SCRIPTS (optional, for rebuilding the candidate list from the text layer)
- Run inside a folder of .txt files produced by: pdftotext FILE.pdf
- scripts/parse.py: helper regex patterns
- scripts/build3.py: strict parser; accepts only unambiguous questions
- The consistency filter used for the 35 items is described in PLAN.md section 2.
